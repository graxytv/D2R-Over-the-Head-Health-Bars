# Attribution

- **SirCabby/D2RCabbyCodes**, https://github.com/SirCabby/D2RCabbyCodes, commit `9260ca9acd3bb5094b9ba9a72395502cb900eb75`: GPL-3.0. Native function signatures and interface/layout research adapted from `src/sites.cpp`, `src/game.cpp`, `src/game.h`, `src/healthbars.cpp`, and accompanying research notes. The new plugin is GPL-3.0-only and supplies its complete corresponding source. Original repository copyright notices remain with their authors.
- **D2RLoader/PluginSDK**, https://github.com/D2RLoader/PluginSDK, commit `03a5af9e0feb3f95f95e148e330e01f6635950df`: MIT. SDK included in `third_party/PluginSDK`; its LICENSE contains the original notice. The SDK supplies the loader interface and display-only overlay service.

This is a custom plugin, not an official release of either upstream project or the Reimagined team. Diablo II: Resurrected belongs to Blizzard Entertainment.

- **RuffDood/RuffnecKk-D2RLoader-Suite**: MIT. MapSense OverlayHost V2 interface copied into src/overlay_host_api.hpp; original MIT notice in third_party/MapSense-API-LICENSE.txt.
- **ocornut/imgui**, v1.91.5, commit f401021d5a5d56fe2304056c391e78f81c8d4b8f: MIT. Included in third_party/imgui with its original LICENSE.txt. Used only for the ABI-checked MapSense shared renderer.
