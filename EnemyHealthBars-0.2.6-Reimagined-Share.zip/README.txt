ENEMY HEALTH BARS 0.2.6 - REIMAGINED
Packaged October 30, 2026 from Graxy_TV's installed plugin and settings.

INSTALL
1. Close Diablo II: Resurrected.
2. Install/configure D2RLoader first if it is not already installed.
3. Extract this ZIP into a temporary folder.
4. Copy the plugins and config folders into:
   <Diablo II Resurrected>/mods/Reimagined/d2rloader/
   The DLL must end up at:
   <game>/mods/Reimagined/d2rloader/plugins/d2rl-enemy-health-bars.dll
5. Launch Reimagined through D2RLoader in HD graphics.
   Use windowed or borderless mode for the standalone overlay.

Back up an existing config before replacing it. Install only one copy of
this DLL; avoid keeping another copy in the global loader plugins folder.

INCLUDED SETTINGS
Blood-red bars, width 64.6, height 6, above monster heads.
Only injured enemies show bars (show_full_health = false).
Rarity outlines are off (rarity_outline = false).
Edit config/enemy-health-bars.toml to change these choices.
Restart the game or run enemybars reload in the loader console afterward.

OPTIONAL LAUNCHER CONTROLS
Import extras/EnemyHealthBars-0.2.6-Launcher-Addon.zip through the Reimagined
Launcher's Mod Add-ons panel. This provides visibility checkboxes; it does
not install the DLL or D2RLoader. Its visibility settings override the native
config when enabled. Both checkboxes initially default to on; turn them off
to reproduce the settings included here.

COMPATIBILITY
The original release targets Windows x64, HD graphics, D2R 3.3.93847,
D2RLoader 1.3.1-beta, and Reimagined 3.0.12. Other versions have not been
verified by this packaging task. MapSense is optional.

CONTENTS AND LICENSE
plugins/ and config/: installed plugin and current native settings.
extras/: optional launcher companion ZIP.
source/: corresponding original 0.2.6 source archive with build dependencies.
LICENSE, THIRD_PARTY.md, licenses/: redistribution and dependency notices.
Original-README.md: original installation and technical documentation.
Its default settings describe the original release; this ZIP uses the
current settings listed above. Packaging did not change or rebuild the DLL.
No saves, logs, game assets, or personal launcher settings are included.

UNINSTALL
Close the game and remove plugins/d2rl-enemy-health-bars.dll from the
installation folder. Disable/remove the optional launcher companion and
apply launcher changes if it was installed. The native config may remain.
