# Enemy Health Bars — Reimagined

Community beta, version 0.2.6. Compact, shaded blood-red health bars above hostile enemies, with optional blue champion and orange unique/boss outlines. Friendly units, mercenaries, summons, neutral NPCs, dead and unattackable units are excluded through the native hostility/eligibility rules. This is a display-only plugin; no combat, drops or saves are changed.

## Compatibility and renderer

- Windows x64, HD graphics, D2R 3.3.93847, D2RLoader 1.3.1-beta, Reimagined 3.0.12.
- Exact executable fingerprint and native function signatures are checked; incompatible builds fail to load.
- MapSense is optional. With a compatible MapSense 2.0.2 host, the plugin shares its verified ImGui 1.91.5 renderer.
- Without that host, version 0.2.6 uses its own click-through, nonactivating Windows layered overlay. It follows the game client area, scales to its size, and hides while the game is minimized or unfocused. No graphics hooks, window subclassing or keyboard/mouse hooks are installed by this renderer.
- Standalone overlay presentation is intended for windowed/borderless modes. True exclusive fullscreen may conceal desktop-composited overlays. This new standalone path has passed build and software-rendering checks but still needs in-game visual confirmation by the user.
- Earlier versions' SDK-overlay fallback did not display on the reported setup and has been removed.
- Legacy graphics are not supported.

## Installation

Close the game. Copy the Install ZIP's plugins and config folders into:

    <game>/mods/Reimagined/d2rloader/

Keep only one copy of d2rl-enemy-health-bars.dll; do not install another global copy. Preserve an existing enemy-health-bars.toml if customized. Launch through D2RLoader.

For launcher checkboxes, import the separate Launcher Add-on ZIP through Reimagined Launcher's Mod Add-ons panel and enable Enemy Health Bars Settings (D2RLoader required). It configures the native DLL and does not install D2RLoader or the DLL itself. Expand Show Parameters to edit:

- Show rarity outlines: blue champions and orange uniques/bosses; off gives all enemies the same dark-framed red bar.
- Always show health bars: include undamaged enemies; off shows only enemies currently below full health. Enemies that heal to full hide again.

Both default to enabled. Settings apply on the next launch. During a session, use Dry Run (Apply Without Launch), then the enemybars reload console command.

The companion writes data/enemy-health-bars-visibility.toml inside the active mod. That file overrides only rarity_outline and show_full_health from the native config. Disabling/deleting the companion restores/removes its managed file on the next launcher apply, returning those settings to the native TOML values. Disabling the settings companion does not disable the native DLL.

## Native config and defaults

    <game>/mods/Reimagined/d2rloader/config/enemy-health-bars.toml

- width = 64.6, height = 6 at 1080p: 15% shorter than the original 76-pixel fill.
- above_heads = true, offset_y = -16; slim bronze inset, black outer keyline.
- Green/yellow/red health-band entries all use #942B28, so there are no threshold color transitions. Highlight and shadow give the red fill depth.
- normal_outline = #000000; champion_outline = #429EFF; unique_outline = #FF9E14.
- outline_width = 2, rarity_outline = true, show_full_health = true.
- Other settings control opacity, HD frame styling, vertical offset and hiding with side panels.

Head placement uses the native model-top projection plus active-mod size metadata from loose monstats.txt and monstats2.txt. The size-aware adjustment lowers small humanoid bars while preserving large-beast placement. It is a bounded calibration rather than exact HD silhouette detection; unusual models may need refinement. Unknown/missing size data retain native placement. Installed Reimagined tables supplied 773 type mappings.

## Commands and troubleshooting

    enemybars
    enemybars on
    enemybars off
    enemybars reload

The status command reports the current renderer, enemy count and faults. On/off apply to the current session. Change enabled in the native TOML to persist it.

For the standalone test, disable MapSense, launch in HD windowed/borderless mode, focus the game and approach enemies. Verify position, red fill, both launcher options, resize/minimize/Alt-Tab behavior and returning to town. The plugin log should report that the standalone transparent renderer is presenting. A successful Windows presentation call alone does not confirm the bars were visible in-game.

Logs: mod-local d2rloader/logs/enemy-health-bars.log and the loader's d2rloader/logs/d2rloader.log. Native read faults disable the plugin until restart.

## Validation

Compilation passed. Automated checks cover raster clipping, premultiplied-alpha blending, opaque-black frames, transparent draws, all four launcher boolean pairs, invalid-config rejection, size adjustments, rarity precedence, normalized health, thresholds and hostile/alive/attackable filtering. The previous MapSense path was visually confirmed. The new standalone renderer and its coexistence with MapSense await in-game confirmation after this change. Dedicated live mercenary/summon checks remain unverified.

## Build and license

Windows x64, Visual Studio C++ tools, Windows SDK and CMake 3.29+:

    cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
    cmake --build build
    build/policy_tests.exe

GPL-3.0-only; complete corresponding source is provided. See LICENSE and THIRD_PARTY.md for original notices and MIT dependencies. No game executable or game assets are included.

## Uninstall

Close the game and remove d2rl-enemy-health-bars.dll. Disable/delete the optional launcher companion and apply the launcher changes to remove its managed visibility file. Native config may remain or be removed. No original game files are replaced.


## Version 0.2.6 motion timing

The user confirmed standalone bars visible in 0.2.5. Version 0.2.6 requests and waits for a fresh native UI position sample before drawing (bounded wait, interruptible on shutdown), removes fixed Sleep(16) pacing from active presentation in favor of DwmFlush, and avoids redundant per-frame z-order updates. This reduces stale-position latency and independent-timer drift without adding positional smoothing or predicting movement. Visual motion stability still requires user testing.

